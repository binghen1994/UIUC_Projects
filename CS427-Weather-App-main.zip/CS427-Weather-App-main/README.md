# CS427-group5
CS427 Milestones

# Term-Project
The code for CS427 Android app. 
<br/>
<br/>

<b>Team # member information</b>
<br/>
| Name                  | NetID         | GitHub ID    | Role          | Experience     |
| -------------         | ------------- | ------------ | ------------- | -------------  |
|   Prithvi  Balaji     |    pbalaji3   |  prithbalaji |  Manager       |   3+ years of Java, prior industry experience |            
|   Aryan Nambiar       |    aryann3    |  ifisq       |  Developer     | 5+ years of Python, no production Java/android experience |
|   Sai Merneedi        |    pmern2     |  pmern2      |  Developer  |    3+ years of Python, no production Java/android experience           |
|   Liran Zuk           |    lzuk2      |  jozuk       |  Developer     |  6+ years of Python, 6mo as Team Leader, no previous Android/Java experience |
|   Biswajit  Pal       |    bpal2      |  palbiswa    |  Tech Lead     |  17+ years of experience in Java, no andriod experience, working as Lead Engineer |
|   Yulu Wang           |    yuluw2     |  binghen1994 |  Developer   | 1+ year of Java, 3+ of C++, Python, no previous Android experience |


<br/>


<b>Weekly Progress Reports</b>
</br> 
<br/>
<br/>

<strong> Milestone1: https://docs.google.com/document/d/1cFy4JVw9fMEV4O6YjZafA4ApozrQ-AoI3mO64JoC6hE/edit?usp=sharing </strong>
</br>
<strong> Milestone2: https://docs.google.com/document/d/11MvHD0CsUraPvl1SNNEf56FR9RUQkuS2c9kp3TDwslU/edit?usp=sharing </strong>

</br>
<strong> Meeting time: Sunday 12pm-2pm(CDT) </strong>
</br> 
<strong> Meeting location (zoom link):https://illinois.zoom.us/j/84421131606?pwd=U1BDTVA5Rkx2OUZkOE9WaCtPMGR1Zz09 </strong>
</br> 
</br>


<b>Week 1 (Milestone1) </b>
</br>
Members present: List the NetID of the people who attended the meeting
<br/>
<br/>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2 </strong>
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
<br/>
<br/>
<strong> It was quick. The meeting went well. Everyone put in there screenshots and was on time. We are ready for milestone2. </strong>
</br>

| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|      pbalaji3          |  Getting repository set up, setting up dev emulator |  Set up milestone 2 and make sure everyone knows their role                     |
| aryann3                |  Verified environment/emulator setup    |                       |
|   pmern2              |   verifired environment setup  |                       |
|    lzuk2            |  Added missing code to the repository and fixed setup, created dev environment and emulator                                |  Add a fully dressed use case, read materials about Android components                      | 
|     bpal2           |  Work space set up, updated graddle and android version    | Work on Informal requirement                      |
|    yuluw2            | Set up weekly meeting, environment set up                                |   Add fully dressed use cases for R005 and R006                    |

</br>


<b>Week 2 (Milestone1) </b>
</br>
Members present: List the NetID of the people who attended the meeting
<br/>
<br/>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2 </strong>
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
<br/>
<br/>
<strong> It was quick. The meeting went well. Everyone put in there screenshots and was on time. We are ready for milestone2. </strong>
</br>

| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|      pbalaji3          |  Getting repository set up, setting up dev emulator |  Set up milestone 2 and make sure everyone knows their role                     |
| aryann3                |  Verified environment/emulator setup    |                       |
|   pmern2              |   verifired environment setup  |                       |
|    lzuk2            |  Added missing code to the repository and fixed setup, created dev environment and emulator                                |  Add a fully dressed use case, read materials about Android components                      | 
|     bpal2           |  Work space set up, updated graddle and android version    | Work on Informal requirement                      |
|    yuluw2            | Set up weekly meeting, environment set up                                |   Add fully dressed use cases for R005 and R006                    |

</br>









<b>Week 3 (Milestone2)</b>
</br>
Members present: List the NetID of the people who attended the meeting
<br/>
<br/>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2,cye11 </strong>
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
<br/>
<br/>
<strong> The meeting went well. Everyone knows what to do. Fully dressed Use Case was divided:
UC001 - pb
UC002 - Aryan
UC003 - joluk
UC004 - Sai
UC005 - yulu
Uc006 - yulu 
Everyone was able to work together on Informal Requirements, Use Cases and set up for  Class Diagram. We got our new team member Rachel as well.  </strong>
</br>

| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|     lzuk2           |    Add a fully dressed use case, read materials about Android components            |  Suggest a class diagram that support the fully dressed use-case     |
|     yuluw2           |     Add fully dressed use cases for R005 and R006                             |   Modify use cases, draw class diagram for R005 and R006               |
|      pbalaji3            |   Add a fully dressed use case (UC001) , Update readme, get new team member up to speed, feedback form          |     Motify class diagram to support our use cases, get ready for Milestone3           |
|bpal2    |   Worked on Component transtion graph, Reviewed deliverables and updated based on review comments    |  Work on Transition graph  |
|       pmern2   |   Add fully dressed use cases for R004  |   class diagram for fully-dressed use case    |
|      aryann3   |   Add fully dressed use cases for R002  |   Create class diagram for fully-dressed use case UC002                  |
|                |                                 |                       |
|                |                                 |                       |
</br>



<b>Week 4 (Milestone 2) </b>
</br>
Members present: List the NetID of the people who attended the meeting
<br/>
<br/>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2,cye11 </strong>
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
<br/>
<br/>
<strong> The meeting went well. We did the meeting one day earlier and we were able to get all deliverables done earlier. Everyone was able to work together on Informal Requirements, Use Cases, Class Diagram, and Transition Graph. We got our new team member Rachel up to speed as well. We are ready for milestone 3. </strong>
</br>

| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|     lzuk2           |    Add a fully dressed use case, read materials about Android components            |  Suggest a class diagram that support the fully dressed use-case     |
|     yuluw2           |     Add class diagrams for R005 and R006 and modify use cases according to new requirement                            |   read android documents and prepare for coding in android studio               |
|      pbalaji3            |   Add a fully dressed use case (UC001) , Update readme, get new team member up to speed, feedback form          |     Motify class diagram to support our use cases, get ready for Milestone3           |
|bpal2    |   Worked on Component transtion graph, Reviewed deliverables and updated based on review comments    |  Work on Transition graph  |
|       pmern2   |   Add fully dressed use cases for R004  |   class diagram for fully-dressed use case    |
|      aryann3   |   Add fully dressed use cases for R002  |   Modify class diagram for UC002 if necessary                    |
|                |                                 |                       |
|                |                                 |                       |
</br>




<b>Week 5 (Milestone 3)</b>
</br>
Members present: List the NetID of the people who attended the meeting
</br>
<br>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2</strong>
</br>
<br>
Meeting notes: <strong> We drafted the initial plan of work and worked on Milestone 3 development. Team worked together for implementation on various items as par task descriptions.</strong>
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|       lzuk2         |        Added "add location" UI functionality                         |     Update user's data in the DB                  |
|       yuluw2         |       Added different themes                          |    Change theme according to user's data in the DB                   |
|    pbalaji3            |   Adding registration activity xml                              |    adding users to database and creating theme.xml                   |
|     bpal2      |  Added Login Page, Validated Login Page, Added tittle based on logged in user |   Database Connectivity using SQLite     |
|     pmern2           |    Show list of locations for each user based on what user saved or deleted                             |      Help other team members with Registration Activity                 |
|      aryann3          |  Deleting a location                               |        Help other team members with UI              |
|                |                                 |                       |
|                |                                 |                       |
</br>


<b>Week 6 (Milestone 3)</b>
</br>
Members present: List the NetID of the people who attended the meeting
</br>
<br>
<strong> Attended: pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2 </strong>
</br>
Meeting notes: <strong> We reviewed the progress of work, discussed road block, issues and worked on Milestone 3 development to meet the requirement for this milestone as a Team:</strong>
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|      yuluw2          |     Change theme according to user's data in the DB, update some UI for activities                            |                       |
|     pbalaji3           |        Finish Registration activity                         |      Start Milestone 4                 |
|     lzuk2           |     Update user's data in the DB, auto render on location list change,  explored API usage                            |     Start Milestone 4                  |
|     bpal2      |   Added Database connection for SQLLite Database, Initialize and create connection, table creation and test data creation through script during Application login, Added session management using Shared Preference                              |   Miles stone 4 planing and start development work                   |
|       pmern2         |    Show list of locations for each user based on what user saved or deleted                             |      Help other team members with Registration Activity                  |
|       aryann3         |       Deleting a location                           |      Help other team members with UI                    |
|                |                                 |                       |
|                |                                 |                       |
</br>





<b>Week 7  (Milestone 4)</b>
Members present: List the NetID of the people who attended the meeting: 
</br>
pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2
</br>
<br>
Meeting notes: Explain the overall team progress and a summary of discussion:
</br>
We drafted the initial plan of work and worked on Milestone 4 development. Team worked together for implementation on various items as par task descriptions.
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|      yuluw2           |     Work on Map Page, add Http request, API entry and parser                |   Get Name of city, lat/long, back button is show data in Map page                    |
|       pbalaji3          |     Work on Weather Page, help teammates with tasks for 4                            |       Work on weather page, name of city, date and time                |
|       lzuk2          |        Work on interactive map of all cities                         |  Finish map page                     |
|       bpal2          |        Work on Main Page Modification                         |  Login to Main Page redirection, show list of 5 cities, add weather and map button                     |
|      pmern2          |       Work on weather data     |   Relevant weather data and layout     |
|       aryann3         |     Work on weather data       |   Relevant weather data and layout    |
|                |                                 |                       |
|                |                                 |                       |
</br>


<b>Week 8  (Milestone 4)</b>
</br>
Members present: List the NetID of the people who attended the meeting:
pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2
</br>
Meeting notes: Explain the overall team progress and a summary of discussion:
We reviewed the progress of work, discussed road block, issues and worked on Milestone 4 development to meet the requirement for this milestone as a Team
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|      yuluw2           |      Get Name of city, lat/long, back button is show data in Map page                                       |      Start Milestone 5                 |
|       pbalaji3          |      Work on weather page, name of city, date and time                              |     Start Milestone 5                       |
|       lzuk2          |            Finish on interactive map of city                     |     Start Milestone 5                       |
|       bpal2          |   Worked on Map and Weather Page redirection. Researched in API implementation and discussed with Team for required implementation, Added addtional Wind condition details                                                          |     Start Milestone 5                       |
|      pmern2          |    Finished weather page with layout                             |     Start Milestone 5                       |
|       aryann3         |      Finished weather page with layout                          |      Start Milestone 5                      |
|                |                                 |                       |
|                |                                 |                       |
</br>


<b>Week 9  (Milestone 5)</b>
</br>
Members present: List the NetID of the people who attended the meeting
pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
We drafted the initial plan of work and worked on Milestone 5 development. Team worked together for implementation on various items as par task descriptions.
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|       lzuk2         |   Added test for adding a new city      |      Finished testing, Worked on code coverage     |
|    pbalaji3            |       contributed to building registration test    |  finish individual test, Worked on code coverage |
|     pmern2    |    contributed to weather tests    |     finish individual test , Worked on code coverage    |
|   bpal2              |    contributed to log in tests     |   finish individual test , Worked on code coverage           |
|  yuluw2          |      contributed to location tests                 |   finish individual test, Worked on code coverage        |
|    aryann3            |     contributed to weather tests                 |  finish individual test, Worked on code coverage  |

</br>


<b>Week 10  (Milestone 5)</b>
</br>
Members present: List the NetID of the people who attended the meeting
pbalaji3,aryann3,pmern2,lzuk2,bpal2,yuluw2
</br>
Meeting notes: Explain the overall team progress and a summary of discussion
We reviewed the progress of work, discussed road block, issues and worked on Milestone 5 development to meet the requirement for this milestone as a Team
</br>
| NetID          | Progress from last week         | Tasks for next week   |
| ---------------| --------------------------------| ----------------------|
|         lzuk2       |           Created Coverage report, Worked on code coverage                      |                       |
|     pmern2           |           contributed to weather tests  , Worked on code coverage                    |                       |
|      aryann3          |       contributed to weather tests   , Worked on code coverage                       |                       |
|      yuluw2          |          contributed to location tests  , Worked on code coverage                     |                       |
|       bpal2         |         contributed to log out tests     , Worked on code coverage                   |                       |
|     pbalaji3           |   contributed to building registration test  , Worked on code coverage                            |                       |
|                |                                 |                       |
|                |                                 |                       |
</br>





